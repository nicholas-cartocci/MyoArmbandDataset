//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: _coder_get_data_Roberto_info.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 24-Nov-2022 11:23:51
//

// Include Files
#include "_coder_get_data_Roberto_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
//
// Arguments    : void
// Return Type  : const mxArray *
//
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced9adb8ed24018c78b59132f3cec956fa12ebb1cbd31b4401784c27292450c5bda59"
      "28b453b60768498c893e803e82f10dbcf511bc305efa14be822e0bc3"
      "4209e946a036b3f3bf997e7c6d7f6d437e99664a0532f90045510fa9693ebf988e0f66f5"
      "fe6cbc432dc7d90fccc6fb8e1ae52eb5b7741cea7f9c8d820a0d6019",
      "d302f20a981f29aa8a04796854ec01a034a0abf21088579d734906154901e5c5829b544a"
      "7aa1352f26adc936d30542bf6c2a94d6d5afaf505e2ce6cfe36ccdfd"
      "eeb93c0f679ccfc3b9df6de1fdfc471e3a7fcf8587faafab6f98e7cdaa0e34bd09055e33"
      "5441909a49553015000dbdc94ac6b1d96ee66d35a1296d1e8a49dee0",
      "7560341955042d4e12facd64a2926895d4b6ddca5f6ee5e84366fa13074c43e3e556891f"
      "3d557863f9feced65cffa31bde9f73bcdeffded5f8fbcfaf8097bc27"
      "f4dbaf5ef250fe17cf5a73be9bfe3f1fafe1ed3bfaf9d1a09fad1743d98629c7aad0e253"
      "7de620797d1d45178edb75506b6aafce7fb6e6785c3ce6350f036fa6",
      "6560492a24dedc050f05776fb2855e160cd85a30927959bb00c7023c94c7c49b2bf1abc7"
      "bce66dea4dd98587fa3bf466ca3200d41de624dedc0e0f05776fe6ce"
      "c7e34a4c1a07f92a6b962307403a280869e24d67fcea31af7918cc379336e4154920f3cd"
      "5df05070f7e6ab767590eb0f84142889bd3acce4c65c2648136f3ae3",
      "578f79cdc3c09bf91a337955bf1ddefcf1e51df126b57d6f1e85ebf620ce87ca74f6d494"
      "e341bdd10e42e2cd95f8d5635ef336f5a6e4c243fddd7af3f2557d59"
      "9bc49b5be2a1e0eecd323d0aa5d2c5ecb0a39f24ba3604a7a1cc29f1e64afcea31af799b"
      "7ab3efc2437d0fd6d38b9a2acccd49bcb91d1e0aeede3c61fad2488c",
      "6455161e6b9aa197c2470d3345bce98c5f3de6350f036fa2f574e2cd1df05070f7a618eb"
      "caf5285be9c0720870b498162a6c8721de74c6af1ef39ab7a9371517"
      "1eea7bb29ebe604ee2cdedf05070f7a62d8535edc888870bd11cb00a275176c091ef3757"
      "e3578f79cdc360be89d6d36fc57cf37bea3df126b57d6f5ac34ab8da",
      "ce5d48726220756a89c445bd5c27efe92bf1abc7bce661e04db49e7e2bbcf9e91bf1e624"
      "5bff0e89638b965e83c3acdd576c9ab6e57a3c42e69b2bf1abc7bce6"
      "6dea4d7f7c8734594f5fd226b6deac3dfb40bc496ddf9be35e34c415e21ca3546211a5d7"
      "10da749ac360bef91768d105ce",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 16312U, &nameCaptureInfo);
  return nameCaptureInfo;
}

//
// Arguments    : void
// Return Type  : mxArray *
//
mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("get_data_Roberto"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(12.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "C:\\Users\\ncartocci\\Documents\\GitHub\\MyoArmbandDataset\\Code_"
          "Nick\\DATA_Roby_MATALB2C\\get_data_Roberto.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738849.47486111114));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2105380 (R2022b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("tg2Phglb7Or0421StkGwkB"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

//
// File trailer for _coder_get_data_Roberto_info.cpp
//
// [EOF]
//
