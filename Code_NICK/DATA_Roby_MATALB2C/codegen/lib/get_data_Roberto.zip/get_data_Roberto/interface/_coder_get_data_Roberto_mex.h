//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: _coder_get_data_Roberto_mex.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 24-Nov-2022 11:23:51
//

#ifndef _CODER_GET_DATA_ROBERTO_MEX_H
#define _CODER_GET_DATA_ROBERTO_MEX_H

// Include Files
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"

// Function Declarations
MEXFUNCTION_LINKAGE void mexFunction(int32_T nlhs, mxArray *plhs[],
                                     int32_T nrhs, const mxArray *prhs[]);

emlrtCTX mexFunctionCreateRootTLS();

void unsafe_get_data_Roberto_mexFunction(int32_T nlhs, mxArray *plhs[12],
                                         int32_T nrhs);

#endif
//
// File trailer for _coder_get_data_Roberto_mex.h
//
// [EOF]
//
