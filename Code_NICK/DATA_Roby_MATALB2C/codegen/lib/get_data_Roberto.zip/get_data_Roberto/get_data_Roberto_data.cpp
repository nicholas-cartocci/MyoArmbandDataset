//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: get_data_Roberto_data.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 24-Nov-2022 11:23:51
//

// Include Files
#include "get_data_Roberto_data.h"

//
// File trailer for get_data_Roberto_data.cpp
//
// [EOF]
//
