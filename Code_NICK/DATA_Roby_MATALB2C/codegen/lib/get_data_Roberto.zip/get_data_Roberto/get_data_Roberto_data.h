//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: get_data_Roberto_data.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 24-Nov-2022 11:23:51
//

#ifndef GET_DATA_ROBERTO_DATA_H
#define GET_DATA_ROBERTO_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for get_data_Roberto_data.h
//
// [EOF]
//
