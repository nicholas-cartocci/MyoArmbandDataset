//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: get_data_Roberto_initialize.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 24-Nov-2022 11:23:51
//

#ifndef GET_DATA_ROBERTO_INITIALIZE_H
#define GET_DATA_ROBERTO_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void get_data_Roberto_initialize();

#endif
//
// File trailer for get_data_Roberto_initialize.h
//
// [EOF]
//
