//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: categorical.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef CATEGORICAL_H
#define CATEGORICAL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct cell_wrap_6;

// Type Definitions
namespace coder {
class categorical {
public:
  static void initDataValueSet(const cell_wrap_6 valueSet_data[],
                               int valueSet_size);
};

} // namespace coder

#endif
//
// File trailer for categorical.h
//
// [EOF]
//
