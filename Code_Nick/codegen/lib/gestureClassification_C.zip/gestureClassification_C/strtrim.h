//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: strtrim.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef STRTRIM_H
#define STRTRIM_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void strtrim(const char x_data[], const int x_size[2], char y_data[],
             int y_size[2]);

}

#endif
//
// File trailer for strtrim.h
//
// [EOF]
//
