//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: strcmp.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef STRCMP_H
#define STRCMP_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
bool b_strcmp(const char a_data[], const int a_size[2], const char b_data[],
              const int b_size[2]);

}
} // namespace coder

#endif
//
// File trailer for strcmp.h
//
// [EOF]
//
