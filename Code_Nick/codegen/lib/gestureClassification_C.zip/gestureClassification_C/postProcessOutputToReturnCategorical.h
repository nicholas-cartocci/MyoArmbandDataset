//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: postProcessOutputToReturnCategorical.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef POSTPROCESSOUTPUTTORETURNCATEGORICAL_H
#define POSTPROCESSOUTPUTTORETURNCATEGORICAL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct cell_wrap_21;

// Function Declarations
namespace coder {
namespace internal {
namespace ctarget {
void DeepLearningNetwork_postProcessOutputToReturnCategorical(
    const cell_wrap_21 scores);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for postProcessOutputToReturnCategorical.h
//
// [EOF]
//
