//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: gestureClassification_C_terminate.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef GESTURECLASSIFICATION_C_TERMINATE_H
#define GESTURECLASSIFICATION_C_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void gestureClassification_C_terminate();

#endif
//
// File trailer for gestureClassification_C_terminate.h
//
// [EOF]
//
