//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: anonymous_function.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef ANONYMOUS_FUNCTION_H
#define ANONYMOUS_FUNCTION_H

// Include Files
#include "gestureClassification_C_internal_types.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
class anonymous_function {
public:
  struct_T workspace;
};

} // namespace coder

#endif
//
// File trailer for anonymous_function.h
//
// [EOF]
//
