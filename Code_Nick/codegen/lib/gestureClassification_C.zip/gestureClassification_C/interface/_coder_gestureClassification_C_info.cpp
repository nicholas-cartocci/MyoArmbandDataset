//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: _coder_gestureClassification_C_info.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

// Include Files
#include "_coder_gestureClassification_C_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
//
// Arguments    : void
// Return Type  : const mxArray *
//
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[58]{
      "789ced5ddb6f2b5b79f7465c4ea502a9540a95106cca8103ec76938b9d0bf0707c8f133b"
      "b1e34b2ec7687b3c1edb138f67267389633fe511a945dd5541a550e8"
      "8196b68756f470a9a02a2f487de89fd03f03f50955aa54c7332bf18c6779cdce4cc6e395"
      "ef7bc9f6fe3ceb5bf3ade5df6f7ddfba459ee40a4f2291c88722869c",
      "7ced3d93bf1f343faf987fdf13b18a5dffc4fcdbb37d46f2bec87b2dcf21fd9f9b7f5949"
      "d4b82bcdf820327deef6c996d4e74546d42a43998b289c2a09975c6b"
      "a269f30257e1fb5c79fac3c1cda77e664a75fbe14675f3ef6497637b65bd1f51baea5d0d"
      "85e90fb7fef8d813e7f77daf4b7ffc0ce38f159bfead5cf2abc92fd5",
      "8b8ad451987e8ad1987a215ec9c713f5b22ecb92a21519b6c77438b57eb4bebabedeac6b"
      "922434a5abbada6514ae556f09acd4e294174d46e5eaaaf1888c1e31"
      "bef3a225bcd018a5c3696afdd9e4dbf567fcd8eb8ac808e3ff3054f537531c27e7394611"
      "79b173c0690349e9d51dfeefb96cf1d3d7307e70eba73f22f809e927",
      "f57e8eaafddca162114bbd1af7ac975d70f54282ecad78ec2f3f22d843fa45f79757ec26"
      "c4f6f8b04bffd8ffde7dffb5c9df773afffd24487bd76fff7a2b487b"
      "481665ef0a539edbfefd07187b2b367d2bda2f9dcbc7dbfd5ea1936692c5dc5a3e3f4adc"
      "d5a348b043aa4704f339a8f28157dcf1ca35c60f6efdf409829f90de",
      "c62b66ad9fdf72caa2f824e2b19f7c87600fe9c3d34f50df70ee0f0dccfb2e2b7f44b6ce"
      "b603b5670aedfc316ae64a89f465b473ba57547bc77a6a774dafa4e9"
      "e18fffc23cefd68f9ced73c4f63da47f2b7792feeaeb7d461398a62249daeb737ff8960f"
      "33bf7141625a38c447eff5d2e37b7d81f05e488fc1fb078b279ed8be",
      "375b3f43c38ebd3a6d0fc609eec6090d8c1f96951720ae30c46f5ed033bbb5cde2f66a6f"
      "a0b42e4bb5f2cee688bd48d1c30b907f989f7fb8c6bcbf5bff3c25f8"
      "07e9edfc72f3d1ac5255e3057551f1c46b1efbc73f10ec21fdc2fbc78cc7eb33ff73d337"
      "82c2bb17df0c38aef8e4ff4881da338576fed0624df172302a6eed14",
      "58653dcf4a4aae764a515eaa8179fea1f088767bbfbca73d54fe11c11ed2bf55bd81dbaa"
      "ca296a5d641945935896afa72456ef73e21820b3bcb6ab37eb85a114"
      "57fa4d466cdd40b23a1e6f27c7a8f8e280677b7591d35e6c71b2c476d5e7e380cffa1e0d"
      "4c3dfdfa3d7ff7ff82c5c7dd973f6d07690f09edf8982e6ea4f7ae32",
      "5aa9b9b123a62ad216dfaff019c047bb3c345ea1f2df87b56768c610a02f53fe25b8f1eb"
      "6198132293660b72fc8a04ec3d8cbda0f0b97a7650dbcc9653e707bb"
      "17d5f3ceb0c86c14d92c3df81c5cfe63c1f8e010e02a5c8757c7ea142773628b13599e53"
      "21ff6108e43f20fff1a0f64ca19d3f20ffe1acb74b50e3fbd76c9fef",
      "ec191a566054956f0f97657c1ff188cf6f13ea87f48be76fa7613d6aade732cc6bfa630f"
      "09edb8ac56049d1573e78c785968c72bf265e124d6a228ef02b860c5"
      "856bccfbc2387ebe3d18c7cff70b8ce30da19d2f601cefacb74b50e3f80f60ed191a790c"
      "143cab2d4d9ede2b5fff2da17e481f4ebe365b6b0ccc308ef7c71e92",
      "65c5e58f60ecadd8f4c944f13c5d2db4aaad563ad92af3a3ab83d2710470d92e6e7159be"
      "a7bd27b6ffc7d9437af3179f9194a3838329fb61c769aff3253f26d4"
      "0fe9178ed3f3e7532dcd17e4781a70fb61ed05359ede2b6dd4fab1abd2daa832cac54aea"
      "e6ce1a9fdba507b70127e6e3049c7f60febfc77e42fbfe8306e6fd81",
      "4fdcd943423b9fc0f907f3cbffa5ed73c4f63da45f389f606844623955cd89b2ae8d633c"
      "6ecc27452bb300af58ed01af00af3ca43d24c02bf3ed90ea11c17c5e"
      "96386579d67f6296854f738a19a34cfbc76b3eea8b04ff20bd8d4f78a9cb882d615cd5e7"
      "8a283e9f54f2c66763d693c7afaa2c8c57bc8e437e41b087f48be695",
      "67772d507f366e82fa9b336d509ff91f9ae72fdea87e39487b4868e7177e143d2c6e95b9"
      "93145f3d6b966ada4935b70afb0b1e0dbf788d57de20f807e9c9f1ca"
      "6469ccd2f2cacf09f6907ed1bce2d44d8c654a3885d163a8e515885b26e237afd4325241"
      "3a8df1e7e98d2cb32e0dca97a9dd4b885b80575cfa07f26086401e6c",
      "be7f804f0ca19d4f68cf833530cf87759dd5ef10ec21fd9829e222db95149b7daf79adb0"
      "afb35a1a7e279e5b61345fd0b88d04ec3d8c3d38bfc29ff21b98e7c3"
      "8adb1fb27db6db43faf10fdfc4809cd8969607b71fcd794338b89e6a3558170b78fdaa78"
      "5d2c1fec54cad13e7fa66495687c7d2d55ca1e005ecf885bbcf6da6e",
      "1f23d843faf12f3fa9ab9ad4cf33434e19a392cc291acfa9cb82db5ec7dbef12ea87f4a1"
      "c56dc7d683732500bf0d718bdf07e7cca09096cba394226d0d8f0ff8"
      "feb1700efb1a6ecba37d5f83579c5f25f807e9e7af173ad435dbd29445f1ef538ffde5df"
      "09f6907ed1f9f7d9f542b36d509ffd2f94d6a1374e80754313f17bdf",
      "73475d132f5b17aade8ea556a5c1d6daf9c66537420fcf3430cf87354e703b3e908d1f7e"
      "8117f926a3b15db4017a59e284e0d67f869dff1d9a91e2f59f70efa2"
      "217ee341b2d74f773bbbbbbbe727ad035d18548ed8548aa27801f0c21d5e78c57dd86760"
      "2d1ff619b8f353d87806e20543609fc1ab95ff398f78f19f98f2576c",
      "fac5f38c0bc030d92629097a5f2c30e79252e3584d5226dfb4ae2787fd0786c0fe03d87f"
      "10843d24b4f30dedfb0f20ae7117d75c63fc00e76ecfb787ca8773b7"
      "9dfd42c23d3877fb61edc1b9dbfe94dfc03cbfeceb57594610e2acc65f321a2f89cb33bf"
      "e115afff8e503fa40f11afdf5e9a61693273661af0da277ba62c2b5e",
      "bb9d9766cff5722cd3cdc44eb6f2996e5155657dad1c01bcb68b5bbcf6da6e1f25d8437a"
      "95d35279630d64726adcb634b8ed755ddabf10ea87f421c46d4cd3d1"
      "9db781f968437c1f6f9f2613495db92c96aaa7329f5893cfb8e45512f0db2e6ef1db2b6e"
      "7e9e600fe931b8e980e8d6fa35ee593fbb049567ff09c11ed22f3a1f",
      "7207d3b34d50c7817524387c79ff9f059c67577ef96e90f690d08ed799586ef7689dd961"
      "4e998a5edcee2acdb8be45d1bc6e03f37c58c7dbbf4fb087f4e3419b"
      "2ec7c5d61177b76774ba1eb48fb7df21d40fe9c339de9e69bac0f11b09d87b187b703e83"
      "3fe53730cf8735bffdbb047b483f018125c46daff9edef13ea87f461",
      "c56dc06b3aed015efb537e03f37c58c7dbbf47b087f4bcc86b3c23f023ce390f423b6e2f"
      "cdb93ab3b83dd374349fab03796d43fcc6edabf3a8a0c4d747a7dbc3"
      "647335d18e7672950eac239991a070dbf5be85db1fffa13209b8cb1aa371cb83db5ef324"
      "ff4ca81fd2871ab7a79b2ee0752580df0f6b2f281ce8ade5879b7b55",
      "21bfad77b25a6955c96c8d62197af0fbb798e7ddfaf11b98f2576cfa85cf8b0937276cd5"
      "137cbe5c294c4edbf2773fd2a7097e407a1b9e4f6af5fc88637545e1"
      "446d52b1c874bd1af7ac975ddcf2abd7fef057047b481f92fe60f53ccdfb5bfff7d35f0a"
      "d21e12daf9615f1c779c9dfd5693bf4a55dbbbec5525b6974fd3c30f",
      "0dccf30f853fd7f7b487ca7f4ab087f48e383cc50ecb8abfb4f07103f39ecb8abf91d69f"
      "ee046acf14daf137ca0c36f7cb99d58badfc41b7da49e4a2b5b36d58"
      "3738236ef147bea7bd2798cf767be8ef5d903ef9f12fcd79c55ef3e13f24d40fe9439d57"
      "319a6c02d8d4e235e45326e2f73e9d1de6f84a6006a3f648ced47a89",
      "7c792bbade89005edb25a8f1f22709f690de71bc3c39d7c5c8592ceb78f92f09f6903e24"
      "e3e53b8fc33e497fed99b2acf8eb76bc9cdd91b4125f49b77aab7d5d"
      "ad8edafaf048a0e8dcc706e6f987c21faf79e3cf11ec21bd23fe66744118262551e4588d"
      "6b2d346f81be785f3ffc0dc11ed28704871d3c0ff90b5fed99423d1e",
      "b3d9f5d1e145f288d30ef60f8f845cbebdd9a5287fe1757cf62d4cf92b367d4870e1ee1c"
      "0b1313fce289cf10fc80f48e3c71a0f73985676fbc826618979527fe"
      "9a600fe943d21fec9ea7ffde0d98679c88df3c71bc5a1e729558657059dee3cb97c37477"
      "2449306e9f91a0c6edaf13ec21bd231edb5862ba5e8d7bd6cb2e41e5",
      "4f68e1e706e63d217fe2d29e29b4e370ed6cafd32f25b34a75d8ce9ea4d70be7bb57704f"
      "eaac0485c39f22d8437a471c2e4b6dadcf5cddadba5b5e1cfe26c11e"
      "d2870487a73d4ff53c228c870df17ddd5d6ab4aee8e7c99e70dcd68a3bec562dce1fa7e8"
      "c1e1471627171955ad741549ef749de364c89f58bff848fa05e44f1e",
      "d81e12daf902f227ce7abb04356ef784c776b688001e8785a71b98f7053c76670f09ed78"
      "bca39f6c8b5daeb523e887fbf11ebfba36e2db148ddf1b98e7c3ba6e"
      "dbedf953ca929e1bf888cf9f52e0bc407aedc1f953fe940ff7af38dfbf728d796fb8476d"
      "be3d543edca3e6ec1712cec17ce9c3da837bd4fc29bf81793eace3fc",
      "0fda3edbed21fd182532ba6a2e6d8e3c9e71fe0f08f543fa10f2b8a5c9d0409fd6bc0cec"
      "cf34c4f7bccc2e93cbaac9edcde19ad44ac4bbd18c9a64e13c931971"
      "8bd7f7b587ca7fcdf6f9ce9ea119ffe82dfb7ec28ecf5ef3e5df25d40fe9c389cff4af77"
      "015c36c46f5c9636c52d9155d3e9542257de691757c5a6c651947ff1",
      "7a3fd7cf30e5afd8f46fe5d2218385dbccec133e275e4a3de3748de2b8209ed5928c2058"
      "fc748df103e463e6db837ccc7cbf403ec610da7904f231ce7abbb8c5"
      "a3e0ee91b8a1063b2b3c9ebccc52df23616b3ab8470270fb55713bd72e24b606ddd5e1fa"
      "215b691fe7f2bd446600eb176724a8bccc07b0f60c8d6cfcdc7d1bb7",
      "fb7d4e97d73c8cfbf35a168dc7b307673d418d13793c3845bb3d5807e34ff9304e731ea7"
      "5d63dedbad5f3e41f00bd263c6d7b763ea655de7fe1d823da45f74de"
      "654e7ecee28f06e67d61dceed29e29b4f3c5a8992b25d297d1cee95e51ed1deba9dd35bd"
      "42d17caad7bcfd2f30e5afd8f4a1cedbd718816f311a77a86be351e6",
      "11a76a876de38cec70ec97d227d9e22ea356f83e97e2fb11ffe2a0f7da3edfd5cbd0b063"
      "d74622fef1c8b7b1f6acfa85f71723ec7836717dfdcef5d4afcbf98b"
      "5fc17ea988ff3c22afb2e91477c8e65ba9e8e5ba1ad5866a9ba6b8037824181ef92cc14f"
      "483f9f47128cc6762744b2ac3ce23e1e09198f20d7d31e8f008f4cc4",
      "6f1e697799763b9e13ba3273981c5c154fa385e20645fb6e8147dcf1c84b8c1fdcfae939"
      "c14f483f874778750c639ca8f292989444556344cd3f3e793fb67e86"
      "46e5c58e30759f7770fbffc2c4270e4d00bce2af3d5368e795ecee40bceaecc9c245b2b7"
      "56ca97d45aa2aa53744f7603f37c58ef75fa38c11ed2b39278c929da",
      "647af4068d2ad2189a644ea90c656eba3e5ef9e2a1d71779e5fd9f10ea87f4219cb79ad7"
      "84d49fcf03f31686f88de7428c3d69f62f529bfd742c551152fc4e3a"
      "7148d1bd240dccf3b4ac370aebbd548fe7fed43917454d2d407a2cb845bb3d587fe44ff9"
      "5ef3bab4dd23e775dcfd79823f907e4e9e46d4fb6599b9b9fa39c5f7",
      "55f3fbcb9af7ff1ed69e551fae3c8db509a8de3f00f99989f8cd1ba5cde1719c6393f142"
      "5ada880d37ba3b85ed18f006f006c61ff7ccd718bcd1b6d42e232903"
      "466919df0f7b7cf2c8f8c5b1a5a8e617b8c776226efbf34730f6566cfaed52f73c9539d6"
      "b7a3d94e365b1bd5e4e2c14604f885565cf0ca2f5f24f803e9e7c425",
      "32a3a85c4e6c730a27b2dc24fdadfa1697043d7ffcf7587b567d48fa871997383501e5f7"
      "a0437c3211bff98367f973ede2225fde572e4eb2bdd568963f3a8cd0"
      "c31f800fcef8e09547fe98e017a49fc3232daecde882767704f674fd1af7ac9f5ddcce13"
      "05774f4198fac94c13503f6f0df7ca18e2779eab5c1a9d8e0e984e4a",
      "39da3e9425a6ca1facf114ad6f8538c41a872c348f24c91adfe7475ceb799fd10aba106f"
      "b550bd107eddb75e1fb67db6d70be9dbbac8de00e68b2e23b6c60189"
      "5ffdc4fd39aba1e827cf6e9ba27edb14549fb30afc6188df71c8ea8e2427a5a3add8d965"
      "3991e3f7a327c7e734c521800b565cf816e67dddfa234af007d23bf2",
      "c7b84a0a7f35ae95c6cb02cf1a235f5de5123a2f68b985c6212b1efbc93b047b481f967e"
      "e2d414f5bba6a03e1e81bc9621be9fb7ba7b50cda7f4e871a753abb5"
      "e4e690dbefa914cdbb034eccc7896bccfbc379ddf3eda1f2e1bc6e67bf90f00eceeb7e58"
      "7b705eb73fe53f9a7b371d0082571302a3a645a629702db8777322c0",
      "1bc01b0f6acf14e08df97648f588603e431e6b3179ac7fc2bcaf5b7f6408fe407af7792c"
      "56e16e8e20913965f2b92c732cdf3695fefd1e3e4aa837d2dbeacd8b"
      "2dee2a27deed977ceab13ffd07a11e481f96fee418c7ce6b323817c45f7ba6d0ce433bb9"
      "d4413555d635662467948b733d3688edc3bd1533e2765cfcf63deda1",
      "f2df24d8437af738ef0c178bf28fd77340fe8d600fe9171d37ccc5f139080ef8ed933d53"
      "68c7efbdeac930911647c5f496922e765aa9789bd9a3683d95d7f98b"
      "7731e5afd8f4a1c68b64875792b25e64c655e3c60fa8cf65bff8e62b04ff20bd7bbeb9a9"
      "6c62ec85bbdade3cbfac7ce3fedca990f71f6b93c07cb9dff64ca19d",
      "6fb8d6fe5aac53d24bab59a638144689f3728ba67bae1b98e7c31a2f7c99600fe95f0dbf"
      "2d6463a96fe39ef5b58b5bff00ffcfe7ff06e6fd01b75dda338576dc"
      "deea8d4a4ce2f468b379da9605f558dd8a71198ae204986ff077ddec3ac11f48ff0af30d"
      "8c2024b3b923e3b965e53faff3deff48a82fd287a59f39cf43984d39",
      "ee71c0433ed93385761e4a70e7dbc749a9299d9fee1c737259ceea3bab14f110e083333e"
      "5c63de1bd64bcdb787ca87f552ce7e21e11cac977a587bb05eca9ff2"
      "217eb1c62f2f31efebd61fab047f20bd635cc0095c9f13b501afde2db6c989458161b9b0"
      "ec1f7f64e7d5cc6911cacfb382f31027e2fb3924ab71498d47b798ad",
      "939a92584ba4aab91143d13c06e083333e5c63de1be290f9f6200e99ef1788430ca19d37"
      "688f4380379c79c36b3c12d67310517d823e4ff7fb587b567d48fa09"
      "9c8318903d24b4f3089c8338bf7cb8efc3fafe3ef04797512b03c97655945ffcf1aaf744"
      "3d4efe986902eaf903e6d10df19b3f0a3959de2e44d5a3fd62b69292",
      "62c52d7db540511c02fc61e50fafe7e87e86e00fa427f007dfe7c6b015591c6f78ed17df"
      "c6dab3eac3c71b86eb1161005ff864cf14daf9425e65d329ee90cdb7"
      "52d1cb7535aa0dd5364df7d23630cfc37de186bc8eb567d53be2ff5dbe63c24c37df0b7e"
      "1c1f8efbc26daeb0dc153eed9706e6bd69c12ddaedc17de1fe94ff5b",
      "ccf36efdf82ddbe788ed7b481f9271fc0c3c84629f83317e676eeb96311715ed4ed61495"
      "39611c754813585fd8b83eb87d7e611ad7939a84de7d7e30af6088df"
      "7c12ebf2b5d47a2eabb42ab5247f78dc6cc5e57812f884363ef13a9fb04af003d23bf209"
      "2bf5655de3d20e93e77ec52b9f22d40fe96df56344491cf6255d7d81",
      "16ce9adf7ba4eb1be6b454b0eb6661fdd3c3da0b8a5ff8e6f1e65eb574991d25f9fd82be"
      "5e5cad9cf4299a77007c70c6876bcc7bc3bad9f9f650f9b06ed6d92f"
      "c01b86d0ce1bb06e767ef9b4f2c642e31417fbf8204e09457f82fd7d41d9338576bea17d"
      "7f5f03f33c2df3ddd71eed3dc5dab3ea1d7923c1e7cb95c224e316fc",
      "fefc70cc734fb9c032c7fd58708a767b30bfed4ff95ee723be81297fc5a65f745ec00916"
      "a6fd70edd10f4f097e407ab778ddb8677dece2961fa11f18d2c0bc27"
      "8ccf5dda3385765e883283cdfd7266f5622b7fd0ad7612b968ed6c1be6a9a9c303aff99f"
      "2f12fc80f48ebca088a291b01654ad6ffcab2d290346698596b7bce6",
      "7d7e48a80fd28724eff30c35d1f83f501bd5cd3682fb90fcb4670aedbcb273b6d63ed968"
      "46a3b583a4b05639922f9a3c4df7d9013e38e383579ef913825f907e"
      "cefadaf18b943546e32c07742cebfeea1f60ed59f561e927c67adad92680fd723edb3385"
      "761ed1cf98cc7eb5d21ca84c54b9cae57b83ec5a12e6aba9c7876bcc",
      "7bbbf5cb1f12fc82f48e3ca231623762ad4fe39ef5b18bdb3cd66fee690f95ff75823da4"
      "0f49bfb8f138d57106ecb330c46f7ea8e91b834d3d55d1844a728fdf"
      "ddad3533f221c419106710fce2c3394ee317c9dac38ca58d33be8fb567d587a59fdc8e23"
      "b28ec3086a7904e20c43dcf6eb8f60ecadd8f465212e4b9226692361",
      "78518d2b576b03be12011ea11d1fae31efedd62f1f27f805e91d7944e53b7d896f4dd7a7"
      "71cffad825a838e3a5edb3dd1ed287a45f981e87fddcc00f86b88d33"
      "ae3afd5e7ebf7bbca68cb2a7aa707ec509b54d8ad64f419ce11c6778bdbf354af00bd2cf"
      "8f333292d267b4323fe2e2622bc5f739515df0b9e35ecf0979076bcf",
      "aa0f4b7fb91d4f383705c41d7edb33655979c56ddc7154c8f78aea91b85f69adb733c95e"
      "f5a8d93f8900afd0ce2bd798f7867ddcf3eda1f2611fb7b35f483807"
      "fbb81fd61eece3f6a77ce00d67de781bf3de6efdf215825f90fe15d7f1a6af6e6e1de7b5"
      "bc24c996fb2cd0b8f8bef5f57a3febc73cf6a39f12ec23fd12f4234b",
      "1bc17a2c9fed99423bef948bf18a7e74a8c5bb2729f9627d949138e99c22de01bc708717"
      "901783bc18e4c522c033e65fc88bbd5af9c033ee78e66d8c1fdcfae9"
      "4b043f21fdfc7867fc6ee6115b63989baeef91285aebdbf058dfa0f9e65fb1f6acfad0f5"
      "a3794d32ee44c0373ed9336559f9c66d5c934d6f1f7351b5df1733f9",
      "516b7333d33b480c29da070f38311f27bc9e3ff859827f907efebd7e094663bb938bfd16"
      "b58e38e2b19f7c076bcfaa0f4b3fb9bdd70fb9de1c80007ff864cf14"
      "daf9a3dd65daed784ee8cacc617270553c8d168a1b297af803e21577f1ca35c60fcbb69e"
      "f8bef1c86f3cda7b89b567d587a49fc07a629fed21a19d2f685f4f0c",
      "7c110c5f84659ffba2f8e2eb587b567d48fa09ec73f7d91e12daf982f67deec017c1ccbb"
      "c7087e42faf9f321b2c2c9e3573dd43559d76e9c989114632a6459e7"
      "417e84b567d587aeff609a02d677f96ccf9465e519b7f3ee4db6b3395c8f1d68edca51a9"
      "2b8842ec84d98bd0c3338013f37102e641ac5f847910431a98f705fe",
      "7069cf9465e50f98073104ce933704d6ffc2fa5f58ff1b011e31ffc2fadf572b3fb8fdcf"
      "a1c009eb35767c768c17022f4f2136f00afa1ef00af04a0478c5fc0b"
      "bcf26ae53730cfd3721fed82ee0937f8a12cb5b53e7335a131f37b7ee58bbe47a817d287"
      "e55eda69574c5f4cfb58f08a767b702fad3fe53730cf031e1bf219ac",
      "3dabde118f8b8caa56ba8aa477ba0893fd8aafdcdfab120e3cb6bbc2725978e4f1e016ed"
      "f60097fd29bf8179fea170d92b4ebe4eb087f4b2a46a632c62395535"
      "a67a2bd211a7e98a986434ae23293ccb08d3f57ae9b15e5f20d40be9ede7101a78f63cc5"
      "71729e631491173be69178c6f751fd9e7ac4f15f11ea87f40bc7f137",
      "1d5c5177d39a74dffb7dfdf6afb782b48784767c1fac162b3b1795eece2e93afa52b9bed"
      "ad43bd4ad1394e0dccf30f85ef41b51b2b8c077a7c7b18175b55b935"
      "4681c93d7acb83e75ef3d83f26d40fe9c389e7cead17e4f9af80df0f6b2fa83c76a93468"
      "0f2a35a195e3a3ebccf6d9e55ead9288d083df8013f371c26b3cf106",
      "c13f486fc37987ca4e96972e8c77bdee1bf939c11ed22f7a3d9653373116f6e2141017f8"
      "690fc9b2f28aeb7d6619a9209dc6f8f3f44696599706e5cbd4ee2545"
      "718157bcf809a6fc159b3e94bc6200c62523f0b79cd2d685242308bedf8bf794e027a487"
      "fb29e07e0ae3fb703f4510f6e07e0a7fca6f609e7f283cbabea73d54",
      "beeb7322c6645034260eed29264b7d20cf64c8c279fe99e992fa9bb7c123ae0969ce3345"
      "b6ceb603b5670aed385ecea6dbec664b1ce6456623ba73261d8a6715"
      "8ae6810127e6e3c435e6fd210e986f0fe280f97e8138c010daf983f638e0a9477c70bf3e"
      "65c1fb7266e8c3fc7bb39d2b275e4a3d6eb2eed04e2837c9a5697f5d",
      "63fc017c32df1ef0c97cbf009f18027c32df0ea91e11cc675af34a28ef7fdf76737b3fe7"
      "4db0319d4d7a2c79a47709f543fa10c5878e0b12accd17dc79d748c0"
      "dec3d883fd04decaff7fc72f1fe3",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 166000U, &nameCaptureInfo);
  return nameCaptureInfo;
}

//
// Arguments    : void
// Return Type  : mxArray *
//
mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("gestureClassification_C"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "C:\\Users\\ncartocci\\Documents\\GitHub\\MyoArmbandDataset\\Code_"
          "Nick\\gestureClassification_C.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738848.69032407412));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2105380 (R2022b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("lkd9AOdwOzn5bikeoWMkUG"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

//
// File trailer for _coder_gestureClassification_C_info.cpp
//
// [EOF]
//
