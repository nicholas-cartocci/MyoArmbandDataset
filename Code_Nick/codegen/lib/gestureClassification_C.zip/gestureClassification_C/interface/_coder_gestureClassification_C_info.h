//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
// File: _coder_gestureClassification_C_info.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 23-Nov-2022 16:37:52
//

#ifndef _CODER_GESTURECLASSIFICATION_C_INFO_H
#define _CODER_GESTURECLASSIFICATION_C_INFO_H

// Include Files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
//
// File trailer for _coder_gestureClassification_C_info.h
//
// [EOF]
//
